<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aqua Wash</title>
    <link rel="icon" href="img/Aqua.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <style>
        body {
            margin: 0;
            padding: 0;
            position: relative;
            height: 100vh;
            font-family: 'open sans', sans-serif;
        }

        h1 {
            font-size: 40px;
            font-weight: bold;
        }

        h2 {
            font-size: 15px;
        }

        header {
            position: relative;
        }

        nav {
            position: absolute;
            top: 0;
            left: 45%;
            transform: translateX(-50%);
            display: flex;
            justify-content: end;
            padding: 0.5em;
            width: 100%;
            box-sizing: border-box;
            border-radius: 5px;
        }

        img {
            max-width: 100%;
            height: auto;
            position: relative;
        }

        .text-overlay {
            position: absolute;
            top: 45%;
            left: 23%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 18px;
            font-weight: bold;
            backdrop-filter: blur(20px); 
            padding: 15px; 
            border-radius: 20px; 
            display: flex;
            align-items: center; 
        }

        .text-overlay img {
            max-width: 90px; 
            margin-right: 10px; 
        }

        .nav-pills .nav-link {
            color: white;
            position: relative;
            transition: color 0.3s; 
        }

        .nav-pills .nav-link::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: transparent;
            transform-origin: bottom right;
            transform: scaleX(0);
            transition: transform 0.3s ease-out, background-color 0.3s;
        }

        .nav-pills .nav-link:hover::before,
        .nav-pills .nav-link:focus::before {
            transform: scaleX(1);
            background-color: #3751FE; 
        }

        .nav-pills .nav-link.active {
            border-radius: 20px; 
            width: 100px;
            background-color: #3751FE;
        }

        .isi{
            padding: 20px;
        }

        .text-overlay h2 {
        margin-bottom: 10px; 
        }

        .btn{
            border-radius: 20px;
            width: 100px;
        }
    </style>
</head>
<body>
    <header>
        
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/4.png" class="d-block w-100" alt="Slide 1">
                </div>
                <div class="carousel-item">
                    <img src="img/5.png" class="d-block w-100" alt="Slide 2">
                </div>
                <div class="carousel-item">
                    <img src="img/3.png" class="d-block w-100" alt="Slide 3">
                </div>
            </div>
        </div>

        <div class="text-overlay">
            <div class="isi">
                <img src="img/Aqua.png" class="foto">
                <h1>Hemat Waktu</h1>
                <h1>Bersih Berarti</h1>
                <h2>Dengan dedikasi tinggi untuk kebersihan dan</h2>
                <h2>pelayanan pelanggan yang luar biasa, laundry kami</h2>
                <h2>menawarkan pengalaman mencuci yang tak tertandingi</h2>
                <h2>memastikan pakaian Anda tetap bersih, segar,</h2>
                <h2>dan terjaga kualitasnya setiap saat.</h2>
                <a class="btn btn-outline-primary" href="#" role="button">Jelajahi</a>
            </div>
        </div>

        <nav>
            <ul class="nav nav-pills">
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <b>HOME</b>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <b>ABOUT</b>
                    </a>
                </li>
                <li class="nav-item2">
                    <center>
                        <a class="nav-link active" aria-current="page" href="login/login.php">Login</a>
                    </center>
                </li>
            </ul>
        </nav>
    </header>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-eSLQdehcs3pukC/4ZrUnrdFkPymU2V86kbxjxzSG/ZZZbDYU0gkFblD5Ac/E1MZ5" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.min.js"></script>
</body>
</html>
