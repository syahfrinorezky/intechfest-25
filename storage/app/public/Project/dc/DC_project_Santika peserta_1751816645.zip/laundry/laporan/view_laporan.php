<?php
session_start();
include '../koneksi.php';
include '../dashboard/dashboard.php';

if(isset($_GET['status'])) {
    if($_GET['status'] == 'baru') {
        $status = "WHERE status='baru'";
    } elseif($_GET['status'] == 'proses') {
        $status = "WHERE status='proses'";
    } elseif($_GET['status'] == 'selesai') {
        $status = "WHERE status='selesai'";
    } elseif($_GET['status'] == 'diambil') {
        $status = "WHERE status='diambil'";
    } else {
        $status = "";
    }
} else {
    $status = "";
}

if(isset($_SESSION['role']) && ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'owner')) {
    $query = mysqli_query($koneksi, "SELECT *, tb_outlet.id AS id_outlet_tb_outlet, tb_outlet.nama AS nama_outlet, tb_transaksi.id AS id_transaksi, tb_member.nama_member AS nama_member FROM tb_detail_transaksi 
    INNER JOIN tb_transaksi ON tb_detail_transaksi.id_transaksi=tb_transaksi.id 
    INNER JOIN tb_member ON tb_transaksi.id_member=tb_member.id 
    INNER JOIN tb_paket ON tb_detail_transaksi.id_paket=tb_paket.id 
    INNER JOIN tb_outlet ON tb_transaksi.id_outlet=tb_outlet.id 
    INNER JOIN tb_user ON tb_transaksi.id_user=tb_user.id $status 
    GROUP BY kode_invoice");
} else {
    $id_outlet = $_SESSION['id_outlet'];
    if($status != "") {
        $outlet = "AND tb_outlet.id='$id_outlet'";
    } else {
        $outlet = "WHERE tb_outlet.id='$id_outlet'";
    }
    $query = mysqli_query($koneksi, "SELECT *, tb_outlet.id AS id_outlet_tb_outlet, tb_outlet.nama AS nama_outlet, tb_transaksi.id AS id_transaksi, tb_member.nama_member AS nama_member FROM tb_detail_transaksi 
    INNER JOIN tb_transaksi ON tb_detail_transaksi.id_transaksi=tb_transaksi.id 
    INNER JOIN tb_member ON tb_transaksi.id_member=tb_member.id 
    INNER JOIN tb_paket ON tb_detail_transaksi.id_paket=tb_paket.id 
    INNER JOIN tb_outlet ON tb_transaksi.id_outlet=tb_outlet.id 
    INNER JOIN tb_user ON tb_transaksi.id_user=tb_user.id $status $outlet 
    GROUP BY kode_invoice");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            font-family: 'roboto';
            background-color: #f7f7f7;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            margin-top: 40px;
            border: 1px solid #f2f2f2;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #3751FE;
            color: #f7f7f7;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        a {
            text-decoration: none;
            color: inherit;
            font-weight: bold;
        }

        .batas-pengambilan {
            font-size: 0.9rem;
            font-style: italic;
        }
    </style>
</head>
<body>
    <center>
        <table border="1" cellspacing="0">
            <thead>
                <tr>
                    <th>Kode Invoice</th>
                    <th>Nama Pelanggan</th>
                    <th>Nama Paket</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while($baris = mysqli_fetch_assoc($query)) { ?>
                    <?php if(isset($_SESSION['role']) && ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'owner')) { ?>
                        <tr>
                            <td align="left">Nama Outlet: <b><?=$baris['nama_outlet']?></b></td>
                        </tr>
                    <?php } ?>
                    <tr>
                        <td align="left">
                            <?php
                            $pecah_string_tanggal = explode(" ", $baris['batas_waktu']);
                            $pecah_string_hari = explode("-", $pecah_string_tanggal[0]);
                            $pecah_string_jam = explode(":", $pecah_string_tanggal[1]);
                            echo "Batas Pengambilan: ".$pecah_string_hari[2]."-".$pecah_string_hari[1]."-".$pecah_string_hari[0]."<br>";
                            echo "Jam: ".$pecah_string_jam[0].":".$pecah_string_jam[1]."<br>";
                            echo "<b>".$baris['kode_invoice']."</b>";
                            ?>
                        </td>
                        <td><?=$baris['nama_member']?></td>
                        <td align="left">
                            <?php
                            $id_transaksi = $baris['id_transaksi'];
                            $query_paket = mysqli_query($koneksi, "SELECT nama_paket, qty FROM tb_detail_transaksi INNER JOIN tb_paket ON tb_detail_transaksi.id_paket=tb_paket.id WHERE id_transaksi='$id_transaksi'");
                            while($data_paket = mysqli_fetch_assoc($query_paket)) {
                                echo $data_paket['nama_paket']."<br>";
                            }
                            ?>
                        </td>
                        <td>
                            <select onchange="pilihStatus(this.options[this.selectedIndex].value, <?=$baris['id_transaksi']?>)">
                                <option value="baru" <?php if($baris['status'] == 'baru') { echo "selected"; } ?>>Baru</option>
                                <option value="proses" <?php if($baris['status'] == 'proses') { echo "selected"; } ?>>Proses</option>
                                <option value="selesai" <?php if($baris['status'] == 'selesai') { echo "selected"; } ?>>Selesai</option>
                                <option value="diambil" <?php if($baris['status'] == 'diambil') { echo "selected"; } ?>>Diambil</option>
                            </select>
                            <script>
                                function pilihStatus(value, id) {
                                    window.location.href = '../edit/proses_edit_status_laporan.php?status=' + value + '&id=' + id;
                                }
                            </script>
                            <?php
                            if($baris['dibayar'] == 'belum_dibayar') {
                                $warna = "#ffbc00"; //kuning
                            } else {
                                $warna = "#60dd60"; //hijau
                            }
                            ?>
                            <a style="color: <?=$warna?>" href="../detail/detail_transaksi.php?id_transaksi=<?=$baris['id_transaksi']?>">Lihat Detail</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </center>
</body>
</html>
