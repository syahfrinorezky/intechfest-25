-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2024 at 04:37 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_laundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_detail_transaksi`
--

CREATE TABLE `tb_detail_transaksi` (
  `id` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `id_paket` int(11) NOT NULL,
  `qty` double NOT NULL,
  `keterangan` text NOT NULL,
  `harga_paket` int(11) NOT NULL,
  `total_harga` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_detail_transaksi`
--

INSERT INTO `tb_detail_transaksi` (`id`, `id_transaksi`, `id_paket`, `qty`, `keterangan`, `harga_paket`, `total_harga`) VALUES
(4, 7, 4, 2, '', 30000, 60000),
(5, 8, 5, 2, 'cepat', 50000, 100000),
(7, 11, 1, 2, 'Tambah deterjen', 25000, 50000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_member`
--

CREATE TABLE `tb_member` (
  `id` int(11) NOT NULL,
  `nama_member` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') NOT NULL,
  `tlp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_member`
--

INSERT INTO `tb_member` (`id`, `nama_member`, `alamat`, `jenis_kelamin`, `tlp`) VALUES
(1, 'Oliva Wulandary ', 'Kpg. Bata Putih No. 205, Tidore Kepulauan 15985, SumBar', 'Perempuan', '0636 8019 281 '),
(2, 'Gangsa Budiman', 'Ki. Gajah Mada No. 62, Tomohon 25805, KalTeng', 'Laki-laki', '0287 5274 2358'),
(3, 'Bakianto Sihombing', 'Kpg. Lumban Tobing No. 831, Tanjung Pinang 70043, KalSel', 'Laki-laki', '0965 1067 614');

-- --------------------------------------------------------

--
-- Table structure for table `tb_outlet`
--

CREATE TABLE `tb_outlet` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `tlp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_outlet`
--

INSERT INTO `tb_outlet` (`id`, `nama`, `alamat`, `tlp`) VALUES
(1, 'Outlet Jakarta', 'Jl Radar Auri Cibubur, Jakarta', ' 021-48975954'),
(2, 'Outlet Bali', 'Jl Nakula 16 Denpasar, Bali', '0-361-23-5147'),
(3, 'Outlet Surabaya', ' Jl Tropodo Indah Bl A/7, Jawa Timur', ' 0-31-867-4184');

-- --------------------------------------------------------

--
-- Table structure for table `tb_paket`
--

CREATE TABLE `tb_paket` (
  `id` int(11) NOT NULL,
  `id_outlet` int(11) NOT NULL,
  `jenis` enum('kiloan','selimut','bed_cover','kaos','lain') NOT NULL,
  `nama_paket` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_paket`
--

INSERT INTO `tb_paket` (`id`, `id_outlet`, `jenis`, `nama_paket`, `harga`) VALUES
(1, 1, 'kiloan', 'Kiloan - Rp.25.000 / Kg', 25000),
(2, 1, 'selimut', 'Selimut - Rp.20.000 / Kg', 20000),
(3, 1, 'bed_cover', 'Bed Cover - Rp.10.000 / Bed Cover', 10000),
(4, 1, 'kaos', 'Kaos - Rp.30.000 / Kg', 30000),
(5, 1, 'lain', 'Paket Kustom - Rp.50.000 / Kg', 50000),
(6, 2, 'kiloan', 'Kiloan - Rp.40.000 / Kg', 40000),
(7, 2, 'selimut', 'Selimut - Rp.45.000 / Kg', 45000),
(8, 2, 'bed_cover', 'Bed Cover - Rp.30.000 / Bed Cover', 30000),
(9, 2, 'kaos', 'Kaos - Rp.20.000 / Kg', 20000),
(10, 2, 'lain', 'Paket Kustom - Rp.50.000 / Kg', 50000),
(11, 3, 'kiloan', 'Kiloan - Rp.30.000 / Kg', 30000),
(12, 3, 'selimut', 'Selimut - Rp.35.000 / Kg', 35000),
(13, 3, 'bed_cover', 'Bed Cover - Rp.30.000 / Bed Cover', 30000),
(14, 3, 'kaos', 'Kaos - Rp.40.000 / Kg', 40000),
(15, 3, 'lain', 'Paket Kustom Harian - Rp.100.000 / Kg', 100000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `id` int(11) NOT NULL,
  `id_outlet` int(11) NOT NULL,
  `kode_invoice` varchar(100) NOT NULL,
  `id_member` int(11) NOT NULL,
  `tgl` datetime NOT NULL,
  `batas_waktu` datetime NOT NULL,
  `tgl_bayar` datetime NOT NULL,
  `biaya_tambahan` int(11) NOT NULL,
  `diskon` double NOT NULL,
  `pajak` double NOT NULL,
  `status` enum('baru','proses','selesai','diambil') NOT NULL,
  `dibayar` enum('dibayar','belum_dibayar') NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id`, `id_outlet`, `kode_invoice`, `id_member`, `tgl`, `batas_waktu`, `tgl_bayar`, `biaya_tambahan`, `diskon`, `pajak`, `status`, `dibayar`, `id_user`) VALUES
(7, 1, 'INV/2024/02/23/1', 1, '2024-02-23 20:34:26', '2024-02-26 20:34:26', '0000-00-00 00:00:00', 10000, 0, 0.0075, 'baru', 'dibayar', 1),
(8, 1, 'INV/2024/02/23/2', 2, '2024-02-23 21:13:59', '2024-02-26 21:13:59', '0000-00-00 00:00:00', 0, 0, 0.0075, 'baru', 'belum_dibayar', 1),
(9, 1, 'INV/2024/02/23/3', 3, '2024-02-23 22:47:58', '2024-02-26 22:47:58', '0000-00-00 00:00:00', 0, 0, 0.0075, 'baru', 'belum_dibayar', 1),
(10, 1, 'INV/2024/02/24/4', 3, '2024-02-24 11:51:27', '2024-02-27 11:51:27', '0000-00-00 00:00:00', 10000, 0, 0.0075, 'baru', 'belum_dibayar', 1),
(11, 1, 'INV/2024/02/24/5', 3, '2024-02-24 22:31:15', '2024-02-27 22:31:15', '0000-00-00 00:00:00', 10000, 0, 0.0075, 'baru', 'dibayar', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `id_outlet` int(11) NOT NULL,
  `role` enum('admin','kasir','owner') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `nama`, `username`, `password`, `id_outlet`, `role`) VALUES
(1, 'Admin', 'Admin', '$2y$10$91bZWluZ/EO/mgnKfDyKkOuInr/ZJSKSiUb692pajSK.CmZbfqRr.', 1, 'admin'),
(2, 'Kasir - Outlet Jakarta', 'Kasir', '$2y$10$B2cCTGLmsfHUVxD1nzRKOend2Ps9Zm037e5YAs8tn7ZMozXBaLbqK', 1, 'kasir'),
(3, 'Owner - Outlet Jakarta', 'Owner', '$2y$10$i69uPHOu7CjGlvWQgheNPulEnOqIV1eO7CnN6IZBxq69fZckBMiUG', 1, 'owner');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_detail_transaksi`
--
ALTER TABLE `tb_detail_transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_detail_transaksi` (`id_transaksi`),
  ADD KEY `FK_detail_paket` (`id_paket`);

--
-- Indexes for table `tb_member`
--
ALTER TABLE `tb_member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_outlet`
--
ALTER TABLE `tb_outlet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_paket`
--
ALTER TABLE `tb_paket`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_paket_outlet` (`id_outlet`);

--
-- Indexes for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_transaksi_outlet` (`id_outlet`),
  ADD KEY `FK_transaksi_member` (`id_member`),
  ADD KEY `FK_transasi_user` (`id_user`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_user_outlet` (`id_outlet`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_detail_transaksi`
--
ALTER TABLE `tb_detail_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_member`
--
ALTER TABLE `tb_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_outlet`
--
ALTER TABLE `tb_outlet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_paket`
--
ALTER TABLE `tb_paket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_detail_transaksi`
--
ALTER TABLE `tb_detail_transaksi`
  ADD CONSTRAINT `FK_detail_paket` FOREIGN KEY (`id_paket`) REFERENCES `tb_paket` (`id`),
  ADD CONSTRAINT `FK_detail_transaksi` FOREIGN KEY (`id_transaksi`) REFERENCES `tb_transaksi` (`id`);

--
-- Constraints for table `tb_paket`
--
ALTER TABLE `tb_paket`
  ADD CONSTRAINT `FK_paket_outlet` FOREIGN KEY (`id_outlet`) REFERENCES `tb_outlet` (`id`);

--
-- Constraints for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD CONSTRAINT `FK_transaksi_member` FOREIGN KEY (`id_member`) REFERENCES `tb_member` (`id`),
  ADD CONSTRAINT `FK_transaksi_outlet` FOREIGN KEY (`id_outlet`) REFERENCES `tb_outlet` (`id`),
  ADD CONSTRAINT `FK_transasi_user` FOREIGN KEY (`id_user`) REFERENCES `tb_user` (`id`);

--
-- Constraints for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD CONSTRAINT `FK_user_outlet` FOREIGN KEY (`id_outlet`) REFERENCES `tb_outlet` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
